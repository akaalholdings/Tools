# Handoff: Geneva — SaaS A (Nocturne)

## Overview
Geneva is an internal web app for a team running Azure SQL Database and Azure Synapse SQL across several environments (PROD, STG, TEST, DEV, SBX). It has one app shell and eight screens:

| # | Screen | Route | Reference file |
|---|---|---|---|
| 1 | Dashboard | `/` or `/dashboard` | `SaaS A - Dashboard.dc.html` |
| 2 | Schema Compare | `/schema-compare` | `SaaS A - Schema Compare.dc.html` |
| 3 | Data Validator | `/data-validator` | `SaaS A - Data Validator.dc.html` |
| 4 | Plan Explorer | `/plan-explorer` | `SaaS A - Plan Explorer.dc.html` |
| 5 | SQL Optimizer | `/sql-optimizer` | `SaaS A - SQL Optimizer.dc.html` |
| 6 | Migration Runs | `/migration-runs` | `SaaS A - Migration Runs.dc.html` |
| 7 | Data Classification | `/data-classification` | `SaaS A - Data Classification.dc.html` |
| 8 | SQL Semantic Evals | `/semantic-evals` | `SaaS A - SQL Semantic Evals.dc.html` |

The users are engineers and data stewards. The UI is dense and keyboard-first. Every screen has a command palette, keyboard shortcuts, a copy-as-cURL/CLI menu, loading/empty/error states, and role-based gating.

## About the design files
The files in `design_files/` are **design references built in HTML**. They are prototypes that show the intended look and behaviour. They are **not production code**. Recreate them in the target codebase's stack and conventions. If there is no front-end yet, use React + TypeScript + Vite with CSS variables from `design_system/nocturne-styles.css`.

- Open any `.dc.html` directly in a browser. Keep `support.js` and the `_ds/` folder beside them (the bundled copy uses `design_system/`; see Files).
- All styling is inline `style="…"` on the elements. **The HTML is the source of truth for exact px values, colours and copy.** Read it; don't ship it.
- Each file ends with a `<script type="text/x-dc">` block containing a `class Component`. That class holds the sample data (top-level `const`s), the state shape (`state = {…}`), keyboard handling (`onScreenKey`), palette actions (`paletteActions`) and the derived view values (`screenVals()`). Read it as the behaviour spec.
- `support.js` is the prototype runtime. Ignore it for implementation.

## Fidelity
**High fidelity.** Colours, type, spacing, copy, columns, states and interactions are final. All data is realistic **sample data**. Put it behind typed service interfaces with mock implementations so screens render the same today and can be wired to real APIs later.

---

## Design language (Nocturne)
A quiet, compact dark UI: blue-grey ground, Inter at medium weight, soft radii, the accent used as a line or glow rather than a flood.

### Tokens (from `design_system/nocturne-styles.css`; use the variables)
- Ground `--color-bg #161826` · surface `--color-surface #232532` (drawers, dialogs, inputs, popovers) · text `--color-text #e9e9ed`
- Accent `--color-accent #9184d9` · ramp `--color-accent-100…900` (`-300 #d2cefd` for accent text on tints, `-900 #2b2741` for the PROD chip / brand tile)
- Neutral ramp `--color-neutral-100…900` (`-500 #9397ab` for "Unreachable", `-700 #595d6c` for the avatar)
- Divider `--color-divider` = text at 16%
- Radius `--radius-sm 4px` (chips, kbd, pills) · `--radius-md 8px` (cards, buttons, rows) · `--radius-lg 14px` (dialogs, palette)
- Shadows `--shadow-md` (popover menus) · `--shadow-lg` (drawer, dialogs, palette, toast)
- Fonts `--font-heading` / `--font-body` = Inter; heading weight 500. Mono = `ui-monospace, SFMono-Regular, Menlo, monospace`

### Semantic colours (literals used throughout; define as tokens)
- OK `oklch(0.68 0.13 150)` · Warning `oklch(0.74 0.14 75)` · Error `oklch(0.64 0.19 25)` · Info = accent · Neutral = `--color-neutral-500`
- Text on a green tint `oklch(0.74 0.12 150)`; red ghost-button text `oklch(0.72 0.15 25)`

### Recurring text tones
- Muted: text at 62% (`color-mix(in srgb, var(--color-text) 62%, transparent)`)
- Secondary paragraph: text at 64–78%
- Row rule: text at 7%. Hover tint: text at 4–7%. Selected row: accent at 16%. Keyboard cursor row: `inset 2px 0 0 var(--color-accent)`

### Type scale
- Page title 20px, weight 500, letter-spacing −0.01em
- Card title 13px / 600 · body and table cells 12.5px · secondary 11.5–12px · kicker labels 10.5px uppercase, letter-spacing .06em
- KPI value 18px / 600, tabular numbers
- Mono identifiers 11.5–12px. All numbers use `font-variant-numeric: tabular-nums`

### Reusable pieces
- **Card**: 1px divider border, radius-md, no fill. Header row min-height 40px, padding 0 12px, bottom border, title 13px/600, right-side actions.
- **KPI strip**: one bordered box split into equal cells with left borders. Cell padding 9px 12px. Label 11.5px muted, value 18px/600, sub-note 11.5px. On narrow widths it wraps (`repeat(auto-fit, minmax(150px, 1fr))`).
- **Status pill**: mono 11px, line-height 18px, padding 0 7px, radius-sm. Border = colour at 45%, background = colour at 14%. Leading 6px dot in the colour.
- **Env chip**: mono 10.5px, padding 0 6px, radius-sm. PROD = `accent-900` bg with `accent-300` text; others = text at 10% bg.
- **Tabs**: text buttons with a 2px bottom border (accent when active). Active is 600 weight in full text colour; inactive is 62% text. Row has bottom divider; tab height 32–40px.
- **Buttons**: design-system `.btn .btn-primary` (accent outline, never filled), `.btn-secondary`, `.btn-ghost`. Heights 24/26/28px in toolbars, font 12–12.5px, 14px Lucide icon + label.
- **Drawer**: fixed right, top 44px (below header), width 460px (max 92vw), surface bg, shadow-lg, top-left radius-md. Header with kicker, title, pill, and ‹ › ✕ buttons (26px). Tab row, scrolling body, footer action bar with top border.
- **Dialog**: backdrop `rgba(0,0,0,0.45)`, centred panel 480–620px, surface bg, radius-lg, shadow-lg.
- **Toast**: bottom-centre, surface bg, shadow-lg, 7px green dot + text. Auto-hides after 1.8s.
- **Icons**: Lucide at stroke-width 1.5, 12–16px. No emoji.
- **Focus**: `*:focus-visible { outline: 2px solid var(--color-accent); outline-offset: 2px }`. Links use the accent and underline on hover.

---

## App shell (every screen)
Grid: `232px sidebar | 1fr main`, full viewport height, body overflow hidden. The main column scrolls internally.

### Sidebar (232px, right divider border, padding 10px, gap 14px)
1. **Workspace switcher**: 26px "G" tile (`accent-900` bg / `accent-300` text) + "Geneva" / "Thirteen Digital · Team" + chevron.
2. **Connection picker**: kicker "CONNECTION"; a 30px button with a green dot, "WideWorldImporters" and a PROD chip. It should open a picker of connections from the connection registry (see Dashboard).
3. **Nav**, grouped under kickers, rows 28px:
   - Overview: Dashboard
   - Compare: Schema Compare (red "1 drift" badge), Data Validator
   - Performance: Plan Explorer, **SQL Optimizer**
   - Delivery: Migration Runs ("1 pending")
   - Governance: Data Classification ("31"), SQL Semantic Evals
   - Active item: accent 16% bg, accent-coloured icon, `aria-current="page"`.
4. Spacer, then Audit log, API keys & CLI, Settings.
5. User footer: 26px avatar "JM", "Jules Moreau", "Role · {role}".

### Header (44px, bottom divider, padding 0 16px)
- Breadcrumb: Geneva / WideWorldImporters / **Screen name**
- Command palette trigger (max 300px): search icon, "Search or run a command…", ⌘K kbd
- Amber "PROD · read-only" badge with lock icon; tooltip "This connection uses a read-only login. Writes go through the approval queue."
- "?" button opens the shortcuts dialog

### Page header (inside main, padding 14px 16px)
H1 + one-line description on the left. Screen actions on the right: Refresh, an **API ▾** menu, and the primary action.
- **API menu** (270px popover): "Copy … as cURL", "Copy CLI command", divider, "API reference ↗", "Manage API keys · 2 active". Copy actions write to the clipboard and show a toast.
- All sample cURL uses base `https://api.geneva.thirteendigital.co.uk/v1` and `Authorization: Bearer $GENEVA_TOKEN`. CLI is `geneva <noun> <verb> … --json`.

### Command palette (⌘K / Ctrl+K)
Centred at 12vh, 620px, radius-lg. Input autofocuses; Esc closes. Results are grouped:
1. **Jump to**: every screen with its G-shortcut hint
2. **Actions**: screen-specific (listed per screen below) + "Keyboard shortcuts"
3. **Results**: screen-specific search hits, shown only when a query is typed (max 6, mono)

↑/↓ moves the highlighted item (accent 18% bg; mouse hover also moves it), ↵ runs it and closes the palette. Empty state: "No matches for "{q}"". Footer hints: ↑↓ navigate · ↵ run · G then letter jumps anywhere · ? all shortcuts.

### Global keyboard
- ⌘K palette · ? shortcuts dialog · Esc closes the topmost layer (dialog → shortcuts → menu → drawer)
- **G then a letter within 900ms**: D Dashboard, S Schema Compare, V Data Validator, P Plan Explorer, O SQL Optimizer, M Migration Runs, C Data Classification, E Semantic Evals
- Single-key shortcuts are ignored while focus is in an input or textarea (Esc blurs the field)
- The shortcuts dialog (520px, two columns) lists screen shortcuts first, then the global ones

### Roles and data states (every screen)
- Role: Viewer / Editor / Admin (Data Classification uses Viewer / Editor / Steward). Gated buttons render `disabled` with a tooltip naming the required role, e.g. "Requires Admin role". Never hide them.
- Data state per screen: `loaded | loading | empty | error`. All four are designed in each file (toggle via the prototype's Tweaks):
  - **loading**: a skeleton table with a one-line status such as "Pinging 5 environments…"
  - **empty**: centred icon tile, title, one sentence, primary CTA
  - **error**: red icon tile, title, cause sentence, mono error code with request id (e.g. `SqlException 297 · request req_Sc81Lq02`), Retry + Copy error

---

## Screens

### 1 · Dashboard
**Purpose**: connection health at a glance, and management of the connection registry.

**Layout**: page header → 4-cell KPI strip → grid `minmax(0,1fr) | minmax(260px,320px)`. The left column holds Connections and Recent activity; the right holds Needs attention and From the wiki.

**KPI strip**: Connected "4 / 5" (red dot, "Sandbox unreachable") · Median latency "12 ms" ("p95 31 ms") · Pending migrations "7" ("STG 2 · DEV 5") · Schema drift "1" (red dot, "GENEVA-TEST · checksum mismatch").

**Connections card**
- Header: "Connections" + "Add database" / "Add Synapse server" button (the label follows the active tab; Admin only).
- Tab row under the header, in this order: **Azure SQL Database (count)**, then **Synapse SQL (count)**. The default is Azure SQL Database. Switching tabs resets the cursor to row 0 and closes the drawer.
- Table columns: Environment (chip + name) · Server / database (host in mono 11.5px over db in muted 11.5px; for Synapse the second line is "db · pool", e.g. "dw_geneva · Dedicated · DW500c") · Ping (right-aligned; a 6px dot, green filled when reachable, red outline for "timeout") · Schema (mono version, e.g. V148) · Pending (right-aligned; "—" when 0) · Status pill (Up to date = OK, Pending = Warning, Drift detected = Error, Unreachable = Neutral).
- Rows are 40px, sticky header 32px. Clicking a row opens the drawer. The row under the keyboard cursor gets the inset accent bar.
- Empty tab: "No connections yet. Add {noun} to start monitoring."
- Sample data: 5 Azure SQL DBs (PROD, STG, TEST, DEV, SBX on `sql-geneva-*.database.windows.net`). 4 Synapse endpoints: PROD dedicated DW500c, PROD serverless (`-ondemand`), DEV dedicated DW100c, and TEST dedicated DW100c, which is paused and so Unreachable.

**Connection drawer** (460px)
- Kicker "Azure SQL Database" or "Synapse SQL", chip + name, status pill; ‹ › step through rows, ✕ closes.
- Tabs: **Overview** · **Checks** · **API** (keys 1/2/3).
- Overview: a red callout when unreachable. The message is per connection: firewall text for SQL DB, "Dedicated SQL pool is paused. Resume it in the Synapse workspace…" for Synapse. Then a key/value grid (130px label column): Server (mono), Database or SQL pool, Pool (Synapse only), Authentication "Managed identity", Login (PROD shows "geneva_reader (read-only)"), Schema version, Pending migrations, Last deploy.
- Checks: the last 6 health checks (dot, "Reachable · 11 ms" or "Timeout after 30s", time).
- API: cURL for `/environments/{code}/health` and `geneva env check {code} --json`, each with Copy; required scope `env:read`.
- Footer: **Test connection** (toast with latency or timeout) · **Edit** (Admin) · **Remove** (Admin; the first click changes the label to "Confirm remove", the second removes and toasts) · "Compare with PROD →" link to Schema Compare.

**Add / Edit connection dialog** (480px)
- Kicker = kind; title "Add database", "Add Synapse server" or "Edit {code}".
- Fields: Code (mono, uppercased on save, e.g. "UAT") and Name, side by side (110px | 1fr). Synapse only: "SQL pool type" toggle, Dedicated or Serverless. Then Server / "Workspace SQL endpoint" (mono) and Database / "SQL pool / database" (mono). Placeholders show the expected host format; the serverless placeholder uses the `-ondemand` host. Authentication is fixed at "Managed identity".
- Validation: Code, Server and Database are required. On failure show the inline red message "Code, server and database are required."
- Save: "Test & add" (new) or "Save" (edit). A new connection must run a real connection test before it is persisted, then it appears in the list selected. Editing keeps the existing pool SKU if the pool type is unchanged. Cancel, backdrop click and Esc all close.

**Recent activity**: rows of **who** + verb + mono target + time; "Audit log →" in the header.

**Needs attention** (count in header): rows with a severity dot, title, sub-line and CTA link (deep-links to the relevant screen).

**From the wiki**: kicker (Runbook / Guide / Policy), title, body, "Read guide →". Dot pager, ‹ › buttons, and "n / 5 · rotates 30s". Auto-advances every 30s.

**Keys**: J/K or ↑/↓ move the cursor (and move the drawer if it's open) · ↵ opens · R refreshes (toast "Refreshed · X of Y connections reachable", counted across both lists).
**Palette actions**: Refresh environment health · Show Azure SQL databases · Show Synapse SQL servers · New schema comparison · Copy health check as cURL. Search matches connections by "CODE · server".

**API needed**: `GET /environments?kind=sqldb|synapse`, `POST /environments` (with test), `PATCH /environments/{id}`, `DELETE /environments/{id}`, `GET /environments/health`, `GET /environments/{id}/checks`, `POST /environments/{id}/test`.

### 2 · Schema Compare
**Purpose**: structural diff between a source (baseline) and a target environment; generate sync scripts.

**Layout**: compare bar (Source select ⇄ swap ⇄ Target select, then "Quick switch" chips DEV / TEST / STG, then a "Differences only" toggle) → summary counts → master/detail: a list of tables grouped by schema on the left, table detail on the right.

**Behaviour**
- Changing source/target, swapping or picking a quick-switch chip reruns the compare. ⇧↵ also runs it; the toast reads "Compared PROD → TEST · 9 differences".
- Table list: filter input (placeholder "Filter tables", focus with /), status filter, "Differences only" (D). J/K move the selection.
- Detail tabs (keys 1–5): Columns · Indexes · Constraints · Foreign keys · Partitions. Diff rows are tinted by status; changed target values are coloured; missing values read "— not present".
- **Table sync script** (S or ↵) opens the drawer with a script preview (Copy), Options (checkboxes: wrap in transaction, include drops, generate rollback, all persisted in state `opts`), and a CLI tab. Footer: **Create migration for approval** (Editor+), then **Apply now** (Admin only, never allowed against PROD). **Full sync script** in the header opens the same drawer in full-database mode.
- States: loading "Comparing PROD and TEST · 63 tables…" · empty "Schemas match" + "Compare another target" · error "Comparison failed", login lacks VIEW DEFINITION, `SqlException 297`.

**Palette**: Run compare · Swap source and target · Open full sync script · Toggle differences only. Search finds tables.

### 3 · Data Validator
**Purpose**: compare row counts between two environments to catch data drift.

**Layout**: compare bar (Source/Target + "Exact counts (COUNT_BIG · slower)" toggle + Differences only) → summary → a row-count table sorted by |delta|, descending. Columns: Table · Source rows · Target rows · Delta (signed value + mini-bar + %) · Status · Last validated. Paging "Page 1 of 16".

**Behaviour**
- Approximate counts come from `sys.dm_db_partition_stats` by default; the Exact toggle switches to COUNT_BIG.
- Clicking a row opens a drawer with tabs **Overview · SQL · API** (1/2/3). Overview has source rows, target rows, method, likely cause, and the last 5 validations. SQL has the count query run on both sides (Copy) and the first 100 sample differing keys. API has REST + CLI for validating one table. Footer: **Re-validate table**, **Create drift ticket**.
- Keys: J/K, ↵, D (differences only).
- States: loading "Counting rows in 156 tables…" · empty "All row counts match" · error "Validation stopped", resource governor after 120s, `SqlException 3980`.

**Palette**: Validate data · Toggle differences only · Export CSV.

### 4 · Plan Explorer
**Purpose**: parse and inspect an execution plan, with an AI review of issues.

Privacy line in the header: "Parsing stays in your browser · AI review sends a summary to the API". Parse ShowPlanXML **client-side**.

**Layout**: input bar (mode: Drop .sqlplan / Paste SQL / Paste plan XML; loaded-file chip "revenue_by_stock_item.sqlplan · 412 KB · actual plan · loaded 14:31 · drop a new file to replace"; Clear) → KPIs (Plan health 62/100 · Est. total cost 1.912 · Operators · Warnings "1 critical · 1 high · 1 medium · 1 low") → Execution plan card → AI review card. The node drawer is open by default.

**Execution plan card**: zoom − / % / + / Fit. Statement text in mono on one ellipsised line. Horizontal operator tree, root at left, with connector line weight ∝ rows. Nodes have default, warning and selected states. Legend: "line weight = rows · arrows flow child → parent · % = share of est. cost · J/K cycle nodes".

**Node drawer** tabs (1/2/3): **Properties** (est/actual rows, costs, executions, with a warning callout for cardinality skew) · **Findings** (the AI findings for this node, or "No findings for this operator.") · **XML** (the RelOp XML, Copy). Footer: Copy node.

**AI review**: "AI review · 4 findings · claude-plan-review v3 · analyzed 14:31". Table of Severity · Finding · Node · Fix, with "Copy fix script". Consent checkboxes under "Sent to the API:" (statement text on, node summaries on, full plan XML off). **Re-analyze** only sends what is checked.

**Keys**: J/→ and K/← cycle nodes · + / − zoom (0.5–1.6) · 0 fit · 1–3 drawer tabs. **Share link** copies a URL.
**States**: loading "Parsing plan XML in your browser…" · empty "Drop a plan to start" · error "This file is not a valid plan", `ParseError at line 1, column 1`.
**Palette**: Re-analyze with AI · Jump to most expensive operator · Zoom to fit.

### 5 · SQL Optimizer (new)
**Purpose**: the user drops in a T-SQL query. The Geneva copilot skill (`geneva/sql-optimizer`) calls MCP tools to inspect the query, rewrites it, and proves the rewrite is equivalent and faster by running both on a chosen environment. The target is Azure SQL Database only.

**Stages**: `input → running → done`. Edit query returns to input with the text kept.

**Page header**
- Title "SQL Optimizer"; description "Drop in a query. The copilot reads its plan, statistics and indexes through the Geneva MCP server, rewrites it, then runs both versions to check the results match."
- Right side: "Benchmark on" select (STG / TEST / DEV; PROD is never used for execution) + the stage actions:
  - input: **Optimize ⌘↵**
  - running: **Cancel** (stops the run, returns to input, toast "Run cancelled")
  - done: **Edit query** (E) and **Copy optimized SQL** (C)

**Input stage**: a full-height editor card (min 360px).
- Header: "Query", a file-name chip once a file is dropped, "Azure SQL Database · T-SQL", **Load sample**, **Clear**.
- A monospace textarea (12.5px, line-height 1.65, spellcheck off) with the placeholder "Paste a T-SQL query, or drop a .sql file here". ⌘/Ctrl+↵ inside it runs the optimizer.
- Drag-over shows a dashed accent overlay "Drop .sql file to load it". Only `.sql` or `.txt` files are accepted (otherwise toast "Drop a .sql file"). The file is read as text into the editor.
- Footer: "{n} lines · {n} chars" and "Benchmarks run as a read-only login inside a transaction that is rolled back."
- Optimizing with an empty query shows the toast "Paste or drop a query first".

**Running and done layout**: grid `minmax(0,1fr) | minmax(260px,330px)`. The right column is the sticky **Copilot rail**.

**Copilot rail**
- Header: "Copilot" + mono chip "geneva/sql-optimizer" + status: "Step n of 9", then "Done in 8.4 s".
- A 2px progress bar (accent, width = steps completed / 9).
- One row per MCP tool call (grid 14px icon | text | duration). The text is the tool name in mono 12px, args in mono 10.5px muted (single line, ellipsised), and the result in 12px.
  - Waiting rows: 45% opacity, hollow icon, no result.
  - Running row: accent ring icon with a 3px glow, accent 8% row bg, result "Calling…".
  - Done rows: green check icon, the result text and the duration in seconds.
- The 9 tools, in order:
  1. `parse_sql`
  2. `get_schema`
  3. `get_estimated_plan` (env=PROD, read-only)
  4. `get_table_stats`
  5. `query_store_lookup`
  6. `rewrite_query` (skill)
  7. `missing_index_advisor`
  8. `verify_equivalence` (static NULL/cardinality rules)
  9. `run_benchmark` (env={chosen} · 5 runs each · rolled back)
- Footer note: "Tools are called through the Geneva MCP server. PROD is read for metadata and estimated plans only."
- In production the rows must be driven by **streamed events from the agent** (SSE or WebSocket: `tool_call_started`, `tool_call_finished {result_summary, duration_ms}`, `run_finished`). The fixed timer in the prototype only simulates this.

**Running stage, main column**: an "Original query" card showing the user's query read-only with line numbers, status "Analyzing…".

**Done stage, main column**
1. **KPI strip**: Estimated cost "1,842 → 96" (−95%) · Median duration "4.21 → 0.18 s" (−96% on {env}) · Logical reads "1.20M → 8.4K" (−99%) · Results "Identical" (12,408 rows). Improvements are shown in green text.
2. **Result card** with tabs (keys 1–4): **Changes (6) · Plan · Proof · Indexes (2)**.
   - **Changes**:
     - Original and optimized queries side by side (they stack under about 560px). Each pane has a header ("Original · 11 lines" / "Optimized · 12 lines"), line numbers and wrapped mono 11.5px text.
     - Lines touched by an issue get a 9% tint (red on the original, green on the optimized side), a 2px left bar and a numbered marker at the end of the line, coloured by severity.
     - Clicking a line or an issue selects that issue. Its lines in **both** panes switch to the accent highlight and the marker fills with the accent. Clicking again deselects.
     - Below the panes is the issue list, headed "6 issues · select one to highlight its lines". Each row has a number badge, the title (12.5px/500), the problem (12px, 72% text), the fix (12px, `accent-300`) and a severity pill (High = Error, Medium = Warning, Low = Neutral).
   - **Plan**: before and after operator lists side by side (they stack when narrow). Headers: "Before · estimated cost 1,842" and "After · estimated cost 96". Each row is indented 14px per depth and shows the operator, detail, cost % and a 3px cost bar (red = problem, amber = warning, green = improved, accent otherwise). Footer: "Estimated plans from PROD metadata…" and "Open in Plan Explorer →", which should deep-link with both plans loaded.
   - **Proof**:
     - A green verdict banner "Same results on {env} · WideWorldImporters" / "Both queries ran 5 times each as a read-only login. Every run was rolled back."
     - A result-check table (Row count, Columns and types, Row checksum sorted, Ordering) comparing Original and Optimized, each marked "Match".
     - A timing table (Duration, Duration p95, CPU time, Logical reads, Memory grant) with a green Change column.
     - "Semantics the copilot checked" notes, for example NOT IN → NOT EXISTS is safe because the column is NOT NULL, and the LEFT JOIN preserves orders with no lines.
     - If any check **fails**, the banner turns red and Copy optimized SQL must show a warning confirm. This state isn't mocked; build it with the error palette.
   - **Indexes**: recommendation cards, each with a kind pill (Index / Statistics), title, a rationale that includes the estimated gain, size and write overhead, the script in a `pre` block, and **Copy SQL**. Footer: "The benchmark was measured without these changes."
3. **Copy optimized SQL** copies the rewritten query and toasts "Copied optimized SQL". This is the only apply action in scope.

**Keys**: ⌘↵ optimize · E edit (done) · C copy (done) · 1–4 tabs (done).
**Palette**: Optimize query · Load sample query · Copy optimized SQL.
**Tweaks in the prototype**: `startWith` (input / running / done) and `runSpeed` (fast / realistic). These are review aids only.

**Backend contract (suggested)**
- `POST /optimizer/runs {sql, env}` → `{runId}`
- `GET /optimizer/runs/{id}/events` (SSE stream of tool steps)
- `GET /optimizer/runs/{id}` → `{original, optimized, issues[{n, severity, title, body, fix, originalLines[], optimizedLines[]}], planBefore[], planAfter[], proof{checks[], timings[], notes[], equivalent}, recommendations[{kind, title, body, sql}], kpis}`

The line mapping per issue is what drives the cross-pane highlighting.

### 6 · Migration Runs
**Purpose**: audit Flyway validate/migrate runs across environments and handle approvals. Source: `flyway_schema_history`.

**Layout**:
1. Approval banner: "Approval requested · V2026.07.4__add_wiki_audit.sql · STAGE → PROD · j.moreau · 13:58 · 2 tables altered · 1 index rebuilt · no data motion · PROD change window 18:00–20:00 CET", with View diff / Hold / **Approve**. Approve needs the release-approver role (tooltip "Release approver role required"). Approving collapses the banner and toasts.
2. KPIs: Last PROD deploy · Success rate 30d · Pending approvals · In flight.
3. Filters: Environment, Status, **Failed only** (F) and an "Auto-refresh 10s" toggle.
4. Runs table: Run · Version · script · Route · Status · Started · Duration · By. Paging "Page 1 of 129". Running rows are info-tinted, failed rows error-tinted.

**Drawer** (a failed run, #1281, is open by default): tabs **Steps · Output · API** (1/2/3). Steps is the numbered step log with status and duration per step. Output is the mono error block (e.g. Msg 2714 …) and the retry resolution note. API is "Get this run via REST", CLI and the required scope. Footer: Open script, Copy error.

**Keys**: J/K, ↵, F. Header buttons: Export CSV, **New run**.
**States**: loading "Reading flyway_schema_history from 5 environments…" · empty "No runs yet" + Copy pipeline snippet · error "Run history unavailable" on GENEVA-STG only (other environments unaffected), `SqlException 208`.
**Palette**: Show failed runs only · Open pending approval · Export CSV.

### 7 · Data Classification
**Purpose**: curate plain-English descriptions and tags for every column so analysts and LLM SQL generation have context. Roles are **Viewer / Editor / Steward**.

**Layout**:
1. A Viewer banner: "You have Viewer access… Editing, AI requests and approvals are disabled." + Request Editor access.
2. KPIs: Context coverage 86.8% (1,599 / 1,842) · Untagged 243 · Pending AI suggestions · Sensitive columns (3 awaiting a steward).
3. Filter bar: Schema / Tag / State / Clear. View toggle **Columns | Steward queue**. A "Visible columns" menu (Conf., Steward, Updated).
4. Catalogue table: checkbox · Column ↑ (mono identity + description; a missing description reads "No description — invisible to the LLM" in amber) · Type · Tags (outlined mono chips; `sensitive` in red; "untagged" placeholder) · State pill (discovered / auto_tagged / needs_review / approved / deprecated / avoid) · Conf. · Steward · Updated. "Rows per page" and "Page 1 of 74".
5. **Bulk bar** when rows are checked: Apply tags · Change state · Assign steward · Approve… (bulk approval asks for evidence).
6. `density` tweak: compact / comfortable row height.

**Drawer**: tabs **Suggestion · Details · API**.
- Suggestion: Current vs Suggested description, Suggested tags, Sensitivity, Masking, Model reasoning. With nothing pending: "No pending suggestion" + Request suggestion.
- Details: data type, nullable, distinct values, used by, object ID, "Open in audit log →".
- API: approve via REST and CLI, required scope, your token.
- Footer: **Approve** · Edit & approve · Request steward review · Reject. Sensitive tags need the Steward role plus evidence. Reviewer and timestamp are recorded, and nothing is ever auto-approved.

**Keys**: J/K move, X select, ↵ open, / focus filter, Esc close drawer or clear selection (see the `SHORTCUTS` const in the file).
**States**: loading "Loading catalogue from WideWorldImporters…" · empty (filters) + Clear filters · error "Couldn't load the catalogue", timeout, last import intact.

### 8 · SQL Semantic Evals
**Purpose**: evaluate natural-language → SQL generation against the curated semantic context (context v18, read-only).

**Layout**:
1. Query card: question input, **Run batch · 24 cases**, **Run eval (⌘↵)**. A 5-cell result strip: Result Passed · Metric · Objects "3 selected of 5 candidates" · Policy "10 of 10 checks passed" · Preview.
2. **Retrieved objects & weights**: weight bars with a 0.60 threshold tick; selected / blocked / not-selected pills; a rationale line per object.
3. **Generated SQL**: provenance "claude sql-gen v2 · prompt p7 · context v18", Copy, code block, and footer "Preview returned 25 rows · limit 100 · executed read-only" + "Open result preview →".
4. **Recent evals** table: Case · Question · Result · P@5 · Verdict (batch #88 · 22 of 24 passed).
5. Right rail with tabs (1–3): **Mapping** (phrase → semantic object; join paths; grain preserved) · **Validation** (checklist) · **Diagnostics** (P@5 / R@5 / MRR + intent note). Actions: Accept / Reject / Create curation task (the last files a task into Data Classification). Viewers can't run or verdict.

**States**: running "Retrieving context → generating SQL → validating…" · empty "Ask a question to evaluate" + Try an example · error "Generation failed", timeout after 30s, retrieval completed, preview not run.
**Palette**: Run eval · Run batch · Copy generated SQL.

---

## State management (per screen)
All of it is listed in each file's `state = {…}` line. In summary:
- **Shell**: paletteOpen, query, highlighted index; shortcutsOpen; toast; open menu; drawerOpen; role; dataState.
- **Dashboard**: kind (`sqldb | synapse`), connections by kind, cursor, activeId, drawer tab, form (add/edit draft + error), confirmRemove, wiki index (30s interval).
- **Schema Compare**: source, target, selected table, tab, differences only, status filter, filter text, script options {tx, drops, rollback}, full-script mode.
- **Data Validator**: source, target, exact, differences only, status, filter text, cursor/active row, drawer tab.
- **Plan Explorer**: input mode, parsed plan, selected node, zoom, drawer tab, consent {stmt, nodes, xml}.
- **SQL Optimizer**: stage, sql, fileName, dragging, current step, result tab, selected issue, env, plus the run result from the API.
- **Migration Runs**: filters, failed only, cursor/active run, drawer tab, approved.
- **Data Classification**: selection map, filters, state filter, visible columns, view tab, cursor/active row, drawer tab.
- **Semantic Evals**: query, rail tab, eval result.

Persist the last-used source/target, benchmark env, active Dashboard tab and table density in localStorage.

## Interactions and motion
- Hovers: 4–7% text tint on rows, menu items and nav. Cursor pointer on everything interactive.
- Transitions: instant, or ≤150ms. The only animated element is the Optimizer progress bar (width, 250ms).
- Every copy action writes to the clipboard and toasts "Copied …".
- Disabled controls sit at 45% opacity (built into the design-system classes) and always have an explanatory `title`.

## Accessibility
Use real `<button>`, `<a>` and `<input>` elements. Give icon-only buttons `aria-label`s. Palette items are options in a listbox with `aria-activedescendant`. Drawers and dialogs trap focus and return it on close. Colour is never the only signal: pills always carry a text label and issue markers carry numbers.

## Assets
There are no image assets. Icons are inline Lucide SVGs (stroke 1.5); use the `lucide-react` package. Inter loads through the design-system stylesheet.

## Screenshots
The PNGs in `screenshots/` were captured at about 924×540, so they show the top of each screen. Open the `.dc.html` beside your build for everything below the fold. The prototypes have a Tweaks panel for role and data state; use it to check the loading, empty and error states.
- `00a` command palette · `00b` shortcuts dialog
- `01a` Dashboard · `01b` Synapse SQL tab · `01c` connection drawer
- `02a` Schema Compare · `02b` table sync script drawer
- `03a` Data Validator with drawer · `03b` without drawer
- `04a` Plan Explorer with node drawer · `04b` without drawer
- `05a` SQL Optimizer input · `05b` running · `05c`–`05f` done: Changes, Plan, Proof and Indexes tabs
- `06a` Migration Runs with the failed-run drawer · `06b` without drawer
- `07a` Data Classification with the suggestion drawer · `07b` without drawer
- `08a` SQL Semantic Evals

## Acceptance checklist (per screen)
- [ ] Side by side with the `.dc.html` at 1440px and 924px wide, spacing, type sizes, colours and copy match
- [ ] All four data states render with the exact copy from the file
- [ ] Viewer, Editor and Admin (or Steward) gating: disabled plus a tooltip, never hidden
- [ ] Every shortcut listed for the screen works, and single keys are ignored while typing in inputs
- [ ] Palette actions and search results for the screen appear and run
- [ ] Every copy action writes the exact cURL, CLI or SQL text from the file and toasts
- [ ] Drawers: ‹ › step rows, number keys switch tabs, Esc closes, focus returns to the row
- [ ] No layout overlap at narrow widths: KPI strips and side-by-side panes wrap

## Files
- `screenshots/`: reference captures (see above)
- `design_files/SaaS A - *.dc.html`: the eight screens (open in a browser; keep `support.js` and the `_ds/` folder beside them)
- `design_files/support.js`: prototype runtime (ignore)
- `design_system/nocturne-styles.css`: the full Nocturne token sheet and component classes
- `IMPLEMENTATION_PROMPT.md`: a ready-to-paste build prompt
