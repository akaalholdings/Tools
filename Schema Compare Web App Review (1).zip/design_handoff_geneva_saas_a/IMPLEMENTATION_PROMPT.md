# Build prompt

Paste this into your coding agent from the repo you're building in, with this folder copied in as `design_handoff_geneva_saas_a/`.

```
Implement the Geneva web app from design_handoff_geneva_saas_a/.

Read README.md end to end first. It specifies the shell, the eight screens,
every interaction, keyboard shortcut, role gate, loading/empty/error state
and the suggested API contracts. The .dc.html files in design_files/ are
high-fidelity references: all styling is inline, and the <script
type="text/x-dc"> block at the bottom of each file holds the sample data,
state shape, keyboard handling and palette actions. Treat those as the
behaviour spec. Do not copy the HTML or support.js; rebuild in this repo's
stack (default: React + TypeScript + Vite, CSS variables from
design_system/nocturne-styles.css, lucide-react at stroke-width 1.5).

Ground rules
- Match the references closely: Nocturne dark tokens, Inter, 8px radii,
  hairline dividers, outlined primary buttons, semantic OK/Warn/Error
  colours as listed in README.
- Build the shared layer first: AppShell (232px sidebar, 44px header,
  breadcrumb, read-only badge), CommandPalette, ShortcutsDialog, global
  key handler (⌘K, ?, Esc stack, G-then-letter), Toast, ApiMenu (copy
  cURL/CLI), Card, KpiStrip, StatusPill, EnvChip, Tabs, DataTable (sticky
  header, hover, keyboard cursor, row click), Drawer (tabs + footer),
  Dialog, StateViews (loading/empty/error with request id + Copy error).
- Every screen supports role (Viewer/Editor/Admin; Steward on Data
  Classification) and dataState (loaded/loading/empty/error). Gated
  actions stay visible, disabled, with a title naming the required role.
- Put all data behind typed service interfaces with mock implementations
  seeded from the sample consts in each file, so screens render
  identically now and can be wired to the real API later.
- Routes: /dashboard, /schema-compare, /data-validator, /plan-explorer,
  /sql-optimizer, /migration-runs, /data-classification, /semantic-evals.
- Transitions instant or ≤150ms. Accessible: real buttons/inputs,
  aria-labels on icon buttons, focus trap in drawers/dialogs,
  :focus-visible 2px accent outline.

Order of work
1. Shell + shared components + palette/shortcuts.
2. Dashboard, including the Connections card with the Azure SQL Database
   tab first, then Synapse SQL, the connection drawer, and the Add/Edit
   dialog with validation, test-before-save and two-step Remove.
3. Schema Compare → Data Validator → Migration Runs.
4. Data Classification → SQL Semantic Evals.
5. Plan Explorer (client-side ShowPlanXML parsing, horizontal operator
   tree, zoom, node drawer, consent-gated AI review).
6. SQL Optimizer: input → running → done. Drive the Copilot rail from
   a streamed event source (SSE) of MCP tool calls; implement a mock
   stream with the nine steps and durations from the file. Build the
   cross-highlighting diff (issue ↔ lines in both panes), Plan, Proof
   and Indexes tabs, and a failed-equivalence state (red banner +
   confirm on copy).

After each screen, open its .dc.html beside your build, check all four
data states and each role, and fix differences before moving on.
```
